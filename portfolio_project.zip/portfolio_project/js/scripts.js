// Load About Me
fetch("./data/aboutMeData.json")
  .then((res) => res.json())
  .then((data) => {
    const aboutMeSection = document.getElementById("aboutMe");
    aboutMeSection.innerHTML = "";
    const frag = document.createDocumentFragment();
    const h2 = document.createElement("h2");
    h2.textContent = "About Me";
    frag.appendChild(h2);
    if (data.headshot) {
      const img = document.createElement("img");
      img.src = data.headshot;
      img.alt = "Headshot";
      img.width = 150;
      img.style.borderRadius = "50%";
      frag.appendChild(img);
    }
    if (data.aboutMe) {
      const p = document.createElement("p");
      p.textContent = data.aboutMe;
      frag.appendChild(p);
    }
    aboutMeSection.appendChild(frag);
  });

// Load Projects
fetch("./data/projectsData.json")
  .then((res) => res.json())
  .then((projects) => {
    const projectsList = document.getElementById("projectsList");
    projectsList.innerHTML = "";
    const frag = document.createDocumentFragment();
    projects.forEach((proj, idx) => {
      const card = document.createElement("div");
      card.className = "project-card";
      // صورة افتراضية إذا لم تتوفر صورة
      const cardImg = proj.card_image && proj.card_image !== "undefined" ? proj.card_image : "./images/card_placeholder_bg.jpg";
      card.style.backgroundImage = `url('${cardImg}')`;
      card.style.backgroundSize = "cover";
      card.style.backgroundPosition = "center";
      card.style.minHeight = "260px";
      card.style.position = "relative";

      // طبقة شفافة فوق الصورة
      const overlay = document.createElement("div");
      overlay.style.background = "rgba(0,0,0,0.25)";
      overlay.style.position = "absolute";
      overlay.style.top = 0;
      overlay.style.left = 0;
      overlay.style.right = 0;
      overlay.style.bottom = 0;
      overlay.style.borderRadius = "10px";
      card.appendChild(overlay);

      // محتوى الكارد
      const content = document.createElement("div");
      content.style.position = "relative";
      content.style.zIndex = 2;
      content.style.display = "flex";
      content.style.flexDirection = "column";
      content.style.alignItems = "center";
      content.style.justifyContent = "center";
      content.style.height = "100%";
      content.style.padding = "20px 10px 10px 10px";

      const h3 = document.createElement("h3");
      h3.textContent = proj.project_name && proj.project_name !== "undefined" ? proj.project_name : "Untitled Project";
      content.appendChild(h3);

      const p = document.createElement("p");
      p.textContent = proj.short_description && proj.short_description !== "undefined" ? proj.short_description : "No description.";
      content.appendChild(p);

      const btn = document.createElement("button");
      btn.textContent = "View More";
      btn.className = "view-more-btn";
      btn.onclick = () => showSpotlight(proj.project_id);
      content.appendChild(btn);

      card.appendChild(content);
      card.style.cursor = "pointer";
      card.addEventListener("click", (e) => {
        // لا تكرر الحدث عند الضغط على الزر
        if (e.target === btn) return;
        showSpotlight(proj.project_id);
      });
      frag.appendChild(card);
    });
    projectsList.appendChild(frag);

    // سبوتلايت افتراضي
    const spotlight = document.getElementById("projectSpotlight");
    function showSpotlight(id) {
      const proj = projects.find((p) => p.project_id === id) || projects[0];
      spotlight.innerHTML = "";
      const spotlightImg = proj.spotlight_image && proj.spotlight_image !== "undefined" ? proj.spotlight_image : "./images/spotlight_placeholder_bg.jpg";
      spotlight.style.background = `url('${spotlightImg}') center/cover`;
      spotlight.style.minHeight = "300px";
      spotlight.style.borderRadius = "12px";
      spotlight.style.display = "flex";
      spotlight.style.flexDirection = "column";
      spotlight.style.justifyContent = "center";
      spotlight.style.alignItems = "center";
      spotlight.style.padding = "30px 10px";
      spotlight.style.position = "relative";
      // طبقة شفافة
      const overlay = document.createElement("div");
      overlay.style.background = "rgba(0,0,0,0.25)";
      overlay.style.position = "absolute";
      overlay.style.top = 0;
      overlay.style.left = 0;
      overlay.style.right = 0;
      overlay.style.bottom = 0;
      overlay.style.borderRadius = "12px";
      spotlight.appendChild(overlay);
      // محتوى السبوتلايت
      const content = document.createElement("div");
      content.style.position = "relative";
      content.style.zIndex = 2;
      content.style.color = "#fff";
      content.style.textAlign = "center";
      const h2 = document.createElement("h2");
      h2.textContent = proj.project_name && proj.project_name !== "undefined" ? proj.project_name : "Project";
      content.appendChild(h2);
      const p = document.createElement("p");
      p.textContent = proj.long_description && proj.long_description !== "undefined" ? proj.long_description : "No description.";
      content.appendChild(p);
      if (proj.url && proj.url !== "undefined" && proj.url !== "") {
        const a = document.createElement("a");
        a.href = proj.url;
        a.target = "_blank";
        a.className = "view-more-btn";
        a.textContent = proj.url.includes("github.com") ? "View on GitHub" : "View Project";
        content.appendChild(a);
      }
      spotlight.appendChild(content);
    }
    // سبوتلايت افتراضي عند التحميل
    showSpotlight(projects[0]?.project_id);
  });

// Scroll buttons for projectsList
document.addEventListener("DOMContentLoaded", () => {
  const projectsList = document.getElementById("projectsList");
  const upBtn = document.getElementById("scrollUpBtn");
  const downBtn = document.getElementById("scrollDownBtn");
  let scrollInterval = null;
  function isMobile() {
    return window.matchMedia("(max-width: 800px)").matches;
  }
  function startScroll(direction) {
    if (scrollInterval) return;
    scrollInterval = setInterval(() => {
      if (isMobile()) {
        projectsList.scrollBy({ left: direction * 20, behavior: "auto" });
      } else {
        projectsList.scrollBy({ top: direction * 20, behavior: "auto" });
      }
    }, 20);
  }
  function stopScroll() {
    clearInterval(scrollInterval);
    scrollInterval = null;
  }
  if (projectsList && upBtn && downBtn) {
    upBtn.addEventListener("mousedown", (e) => { e.preventDefault(); startScroll(-1); });
    upBtn.addEventListener("mouseup", stopScroll);
    upBtn.addEventListener("mouseleave", stopScroll);
    upBtn.addEventListener("touchstart", (e) => { e.preventDefault(); startScroll(-1); });
    upBtn.addEventListener("touchend", stopScroll);
    downBtn.addEventListener("mousedown", (e) => { e.preventDefault(); startScroll(1); });
    downBtn.addEventListener("mouseup", stopScroll);
    downBtn.addEventListener("mouseleave", stopScroll);
    downBtn.addEventListener("touchstart", (e) => { e.preventDefault(); startScroll(1); });
    downBtn.addEventListener("touchend", stopScroll);
    // single click fallback
    upBtn.addEventListener("click", (e) => {
      e.preventDefault();
      if (isMobile()) {
        projectsList.scrollBy({ left: -150, behavior: "smooth" });
      } else {
        projectsList.scrollBy({ top: -150, behavior: "smooth" });
      }
    });
    downBtn.addEventListener("click", (e) => {
      e.preventDefault();
      if (isMobile()) {
        projectsList.scrollBy({ left: 150, behavior: "smooth" });
      } else {
        projectsList.scrollBy({ top: 150, behavior: "smooth" });
      }
    });
  }
});

// Contact Form Validation
const form = document.getElementById("contactForm");
const emailInput = document.getElementById("email");
const messageInput = document.getElementById("message");
const emailError = document.getElementById("emailError");
const messageError = document.getElementById("messageError");
const charCount = document.getElementById("charCount");

messageInput.addEventListener("input", () => {
  const remaining = 300 - messageInput.value.length;
  charCount.textContent = `${remaining} characters remaining`;
  if (remaining < 0) {
    charCount.classList.add("error");
  } else {
    charCount.classList.remove("error");
  }
});

form.addEventListener("submit", (e) => {
  e.preventDefault();
  let valid = true;

  // Email validation
  if (!emailInput.value.includes("@")) {
    emailError.textContent = "Please enter a valid email";
    valid = false;
  } else {
    emailError.textContent = "";
  }

  // Message validation
  if (messageInput.value.length < 10) {
    messageError.textContent = "Message must be at least 10 characters";
    valid = false;
  } else {
    messageError.textContent = "";
  }

  if (valid) {
    alert("Form submitted successfully!");
    form.reset();
    charCount.textContent = "300 characters remaining";
  }
});
